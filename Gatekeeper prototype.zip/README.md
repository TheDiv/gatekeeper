
# three-boilerplate

Welcome to the **three-boilerplatee** README! This document provides an overview of the project, setup instructions, usage examples, and more.


## Installation

Find the package 'three-boilerplate' in nodemodules folder. \
Put it in root folder delete all except the package. 

Then, cd three-boilerplate 

npm install 

npm run dev. 

Three-boilerplate in root directory soon.