import * as THREE from "three";
import "./style.css";
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

/**
 * GATEKEEPER - A 3D Roguelite Defense Game
 *
 * Architecture:
 * - Game: Main game state manager
 * - Player: Demon with horns and spikes, WASD + dash + multiple weapons
 * - Weapon: Modular weapon system with 6 types (shadoworb, aoe, explosion, laser, flamethrower, lightning)
 * - Enemy: Angels with halos and wings (normal, fast, tank, elite)
 * - Chest: Drops from elite enemies, contains new weapons
 * - Gate: Gates of Hell that must be defended with animated flames
 */

class Player {
  constructor(scene) {
    this.scene = scene;

    // Weapon system
    this.weapons = [new Weapon('shadoworb')]; // Start with shadow orb
    this.weaponFireTimers = {};
    this.weapons.forEach(w => this.weaponFireTimers[w.type] = 0);

    // Create demon player mesh
    const bodyGeometry = new THREE.BoxGeometry(0.5, 0.6, 0.5);
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0x8b0000, // Dark red
      emissive: 0xff0000, // Red glow
      emissiveIntensity: 0.6,
      roughness: 0.3
    });
    this.mesh = new THREE.Mesh(bodyGeometry, bodyMaterial);
    this.mesh.position.set(0, 0.3, 0);
    scene.add(this.mesh);

    // Add demon horns (two cones)
    const hornGeometry = new THREE.ConeGeometry(0.08, 0.3, 6);
    const hornMaterial = new THREE.MeshStandardMaterial({
      color: 0x330000, // Very dark red/black
      emissive: 0x660000,
      emissiveIntensity: 0.8
    });

    // Left horn
    this.leftHorn = new THREE.Mesh(hornGeometry, hornMaterial);
    this.leftHorn.position.set(-0.15, 0.5, 0);
    this.leftHorn.rotation.z = -0.3;
    scene.add(this.leftHorn);

    // Right horn
    this.rightHorn = new THREE.Mesh(hornGeometry, hornMaterial);
    this.rightHorn.position.set(0.15, 0.5, 0);
    this.rightHorn.rotation.z = 0.3;
    scene.add(this.rightHorn);

    // Add spikes on back
    const spikeGeometry = new THREE.ConeGeometry(0.06, 0.2, 4);
    this.spikes = [];
    for (let i = 0; i < 3; i++) {
      const spike = new THREE.Mesh(spikeGeometry, hornMaterial);
      spike.position.set(0, 0.2 + i * 0.15, -0.25);
      spike.rotation.x = Math.PI / 2;
      scene.add(spike);
      this.spikes.push(spike);
    }

    // Movement properties
    this.velocity = new THREE.Vector3();
    this.speed = 5;

    // Input state
    this.keys = { w: false, a: false, s: false, d: false };

    this.setupInput();
  }

  addWeapon(weaponType) {
    // Check if weapon already exists
    const existing = this.weapons.find(w => w.type === weaponType);
    if (existing) {
      existing.upgrade();
      return;
    }

    const weapon = new Weapon(weaponType);
    this.weapons.push(weapon);
    this.weaponFireTimers[weaponType] = 0;
  }

  setupInput() {
    window.addEventListener('keydown', (e) => {
      const key = e.key.toLowerCase();
      if (key in this.keys) this.keys[key] = true;
    });

    window.addEventListener('keyup', (e) => {
      const key = e.key.toLowerCase();
      if (key in this.keys) this.keys[key] = false;
    });
  }

  update(deltaTime, enemies, projectiles, effects) {
    if (!this.mesh || !this.scene) return;

    // Movement
    this.velocity.set(0, 0, 0);

    if (this.keys.w) this.velocity.z -= 1;
    if (this.keys.s) this.velocity.z += 1;
    if (this.keys.a) this.velocity.x -= 1;
    if (this.keys.d) this.velocity.x += 1;

    if (this.velocity.length() > 0) {
      this.velocity.normalize();
      this.velocity.multiplyScalar(this.speed * deltaTime);
      this.mesh.position.add(this.velocity);

      this.mesh.position.x = Math.max(-8, Math.min(8, this.mesh.position.x));
      this.mesh.position.z = Math.max(-5, Math.min(5, this.mesh.position.z));

      // Update horns and spikes to follow player
      if (this.leftHorn) {
        this.leftHorn.position.x = this.mesh.position.x - 0.15;
        this.leftHorn.position.z = this.mesh.position.z;
      }
      if (this.rightHorn) {
        this.rightHorn.position.x = this.mesh.position.x + 0.15;
        this.rightHorn.position.z = this.mesh.position.z;
      }
      this.spikes.forEach((spike, i) => {
        spike.position.x = this.mesh.position.x;
        spike.position.z = this.mesh.position.z - 0.25;
        spike.position.y = 0.2 + i * 0.15;
      });
    }

    // Fire all weapons
    this.weapons.forEach(weapon => {
      // Passive weapons (Nova Pulse) always tick
      if (weapon.isPassive) {
        this.weaponFireTimers[weapon.type] += deltaTime;
        const fireInterval = 1 / weapon.fireRate;

        if (this.weaponFireTimers[weapon.type] >= fireInterval) {
          this.fireWeapon(weapon, enemies, projectiles, effects);
          this.weaponFireTimers[weapon.type] = 0;
        }
      } else {
        // Active weapons fire normally
        this.weaponFireTimers[weapon.type] += deltaTime;
        const fireInterval = 1 / weapon.fireRate;

        if (this.weaponFireTimers[weapon.type] >= fireInterval) {
          this.fireWeapon(weapon, enemies, projectiles, effects);
          this.weaponFireTimers[weapon.type] = 0;
        }
      }
    });
  }

  fireWeapon(weapon, enemies, projectiles, effects) {
    if (!this.mesh || !this.mesh.position) return;

    // AOE weapon doesn't need a target (always on)
    if (weapon.effect === 'aoe') {
      this.fireAOEWeapon(weapon, enemies, effects);
      return;
    }

    // Other weapons need enemies
    if (!enemies || enemies.length === 0) return;

    // Find nearest enemy
    let nearestEnemy = null;
    let nearestDistance = weapon.range;

    for (const enemy of enemies) {
      if (!enemy || !enemy.mesh || !enemy.mesh.position || !enemy.alive) continue;
      const distance = this.mesh.position.distanceTo(enemy.mesh.position);
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestEnemy = enemy;
      }
    }

    if (!nearestEnemy) return;

    // Fire based on weapon type
    switch(weapon.effect) {
      case 'projectile':
        this.fireProjectileWeapon(weapon, nearestEnemy, projectiles);
        break;
      case 'explosion':
        this.fireExplosionWeapon(weapon, nearestEnemy, projectiles);
        break;
      case 'laser':
        this.fireLaserWeapon(weapon, nearestEnemy, enemies, effects);
        break;
      case 'flamethrower':
        this.fireFlamethrowerWeapon(weapon, enemies, effects);
        break;
      case 'lightning':
        this.fireLightningWeapon(weapon, nearestEnemy, enemies, effects);
        break;
    }
  }

  fireProjectileWeapon(weapon, target, projectiles) {
    const projectileCount = weapon.projectileCount || 1;
    const spreadAngle = Math.PI / 8;

    for (let i = 0; i < projectileCount; i++) {
      const direction = new THREE.Vector3()
        .subVectors(target.mesh.position, this.mesh.position)
        .normalize();

      if (projectileCount > 1) {
        const offset = (i - (projectileCount - 1) / 2) * spreadAngle / Math.max(projectileCount - 1, 1);
        const cos = Math.cos(offset);
        const sin = Math.sin(offset);
        const newX = direction.x * cos - direction.z * sin;
        const newZ = direction.x * sin + direction.z * cos;
        direction.x = newX;
        direction.z = newZ;
        direction.normalize();
      }

      const projectile = new Projectile(
        this.scene,
        this.mesh.position.clone(),
        direction,
        weapon
      );
      projectiles.push(projectile);
    }
  }

  fireAOEWeapon(weapon, enemies, effects) {
    // Nova Pulse is always-on, no visual effect per tick (performance)
    // Damage enemies in range around player
    enemies.forEach(enemy => {
      if (!enemy || !enemy.alive) return;
      const distance = this.mesh.position.distanceTo(enemy.mesh.position);
      if (distance <= weapon.range) {
        enemy.takeDamage(weapon.damage);
      }
    });
  }

  fireExplosionWeapon(weapon, target, projectiles) {
    const direction = new THREE.Vector3()
      .subVectors(target.mesh.position, this.mesh.position)
      .normalize();

    const projectile = new Projectile(
      this.scene,
      this.mesh.position.clone(),
      direction,
      weapon
    );
    projectiles.push(projectile);
  }

  fireLaserWeapon(weapon, target, enemies, effects) {
    // Create laser beam effect
    const direction = new THREE.Vector3()
      .subVectors(target.mesh.position, this.mesh.position)
      .normalize();

    const effect = {
      type: 'laser',
      start: this.mesh.position.clone(),
      end: this.mesh.position.clone().addScaledVector(direction, weapon.range),
      damage: weapon.damage,
      lifetime: 0.1,
      age: 0,
      color: weapon.color
    };
    effects.push(effect);

    // Damage first enemy hit
    enemies.forEach(enemy => {
      if (!enemy || !enemy.alive) return;
      const distance = this.mesh.position.distanceTo(enemy.mesh.position);
      if (distance <= weapon.range) {
        const toEnemy = new THREE.Vector3().subVectors(enemy.mesh.position, this.mesh.position).normalize();
        const dot = direction.dot(toEnemy);
        if (dot > 0.99) { // Hit if aligned
          enemy.takeDamage(weapon.damage);
        }
      }
    });
  }

  fireFlamethrowerWeapon(weapon, enemies, effects) {
    // Create flamethrower cone effect
    const effect = {
      type: 'flamethrower',
      position: this.mesh.position.clone(),
      direction: new THREE.Vector3(1, 0, 0), // Right
      range: weapon.range,
      damage: weapon.damage,
      lifetime: 0.2,
      age: 0,
      color: weapon.color
    };
    effects.push(effect);

    // Damage enemies in cone
    enemies.forEach(enemy => {
      if (!enemy || !enemy.alive) return;
      const toEnemy = new THREE.Vector3().subVectors(enemy.mesh.position, this.mesh.position);
      const distance = toEnemy.length();

      if (distance <= weapon.range) {
        toEnemy.normalize();
        const dot = effect.direction.dot(toEnemy);
        if (dot > 0.5) { // Cone angle
          enemy.takeDamage(weapon.damage);
        }
      }
    });
  }

  fireLightningWeapon(weapon, target, enemies, effects) {
    // Chain lightning - hits initial target then jumps to nearby enemies
    const hitEnemies = new Set();
    const chainPositions = [this.mesh.position.clone()];
    let currentTarget = target;
    const chainCount = weapon.chainCount + 1; // +1 for initial hit

    for (let i = 0; i < chainCount && currentTarget; i++) {
      if (hitEnemies.has(currentTarget)) break;

      hitEnemies.add(currentTarget);
      chainPositions.push(currentTarget.mesh.position.clone());

      // Damage current target (reduced damage for each jump)
      const damageMultiplier = Math.pow(0.8, i); // 80% damage per jump
      currentTarget.takeDamage(weapon.damage * damageMultiplier);

      // Find next target within chain range
      let nextTarget = null;
      let nearestDistance = weapon.chainRange;

      for (const enemy of enemies) {
        if (!enemy || !enemy.alive || hitEnemies.has(enemy)) continue;
        const distance = currentTarget.mesh.position.distanceTo(enemy.mesh.position);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nextTarget = enemy;
        }
      }

      currentTarget = nextTarget;
    }

    // Create visual effect for the entire chain
    const effect = {
      type: 'lightning',
      chainPositions: chainPositions,
      lifetime: 0.15,
      age: 0,
      color: weapon.color
    };
    effects.push(effect);
  }
}

class Projectile {
  constructor(scene, position, direction, weapon) {
    this.scene = scene;
    this.direction = direction;
    this.speed = weapon.projectileSpeed || 15;
    this.damage = weapon.damage;
    this.pierceCount = weapon.pierceCount || 0;
    this.piercesRemaining = this.pierceCount;
    this.alive = true;
    this.isExplosive = weapon.effect === 'explosion';
    this.explosionRadius = weapon.explosionRadius || 0;

    // Create projectile mesh
    const geometry = new THREE.SphereGeometry(0.15, 8, 8);
    const material = new THREE.MeshBasicMaterial({
      color: weapon.color,
      emissive: weapon.color,
      emissiveIntensity: 1.0
    });
    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.position.copy(position);
    scene.add(this.mesh);
  }

  update(deltaTime) {
    if (!this.alive) return;

    this.mesh.position.addScaledVector(this.direction, this.speed * deltaTime);

    // Remove if out of bounds (smaller play area)
    if (Math.abs(this.mesh.position.x) > 12 || Math.abs(this.mesh.position.z) > 8) {
      this.destroy();
    }
  }

  onHit() {
    if (this.piercesRemaining > 0) {
      this.piercesRemaining--;
    } else {
      this.destroy();
    }
  }

  destroy() {
    this.alive = false;
    this.scene.remove(this.mesh);
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}

class Enemy {
  constructor(scene, spawnPosition, type = 'normal', difficultyMultiplier = 1.0) {
    this.scene = scene;
    this.type = type;
    this.alive = true;

    // Set stats based on type
    this.setTypeStats(type);

    // Apply difficulty multiplier to HP
    this.hp = Math.floor(this.hp * difficultyMultiplier);
    this.maxHp = this.hp;

    // Create enemy mesh with type-specific color
    const geometry = new THREE.SphereGeometry(this.size, 8, 8); // Reduced poly count from 16,16
    const material = new THREE.MeshStandardMaterial({
      color: this.color,
      emissive: this.color,
      emissiveIntensity: 0.5,
      metalness: 0.3,
      roughness: 0.2
    });
    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.position.copy(spawnPosition);
    scene.add(this.mesh);

    // Only add halo to elite enemies for performance
    if (this.type === 'elite') {
      const haloGeometry = new THREE.TorusGeometry(this.size * 0.8, this.size * 0.1, 6, 12); // Reduced poly count
      const haloMaterial = new THREE.MeshBasicMaterial({
        color: 0xffd700, // Gold
        emissive: 0xffd700,
        emissiveIntensity: 2.0
      });
      this.halo = new THREE.Mesh(haloGeometry, haloMaterial);
      this.halo.position.set(spawnPosition.x, spawnPosition.y + this.size * 1.3, spawnPosition.z);
      this.halo.rotation.x = Math.PI / 2;
      scene.add(this.halo);

      // Add simple wings (two flat triangles) for elite enemies
      const wingShape = new THREE.Shape();
      wingShape.moveTo(0, 0);
      wingShape.lineTo(0.4, 0.3);
      wingShape.lineTo(0, 0.6);
      const wingGeometry = new THREE.ShapeGeometry(wingShape);
      const wingMaterial = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        emissive: 0xffffcc,
        emissiveIntensity: 0.8,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9
      });

      // Left wing
      this.leftWing = new THREE.Mesh(wingGeometry, wingMaterial);
      this.leftWing.position.set(spawnPosition.x - this.size * 0.5, spawnPosition.y, spawnPosition.z);
      this.leftWing.rotation.y = Math.PI / 2;
      scene.add(this.leftWing);

      // Right wing
      this.rightWing = new THREE.Mesh(wingGeometry, wingMaterial);
      this.rightWing.position.set(spawnPosition.x + this.size * 0.5, spawnPosition.y, spawnPosition.z);
      this.rightWing.rotation.y = -Math.PI / 2;
      scene.add(this.rightWing);
    }

    // Only create health bars for elite enemies (performance optimization)
    if (this.type === 'elite') {
      // Create health bar background
      const hpBgGeometry = new THREE.PlaneGeometry(0.5, 0.08);
      const hpBgMaterial = new THREE.MeshBasicMaterial({ color: 0x330000 });
      this.hpBarBg = new THREE.Mesh(hpBgGeometry, hpBgMaterial);
      this.hpBarBg.position.set(spawnPosition.x, spawnPosition.y + 0.5, spawnPosition.z);
      this.hpBarBg.rotation.x = -Math.PI / 4;
      scene.add(this.hpBarBg);

      // Create health bar foreground
      const hpFgGeometry = new THREE.PlaneGeometry(0.45, 0.05);
      const hpFgMaterial = new THREE.MeshBasicMaterial({
        color: 0xff0000,
        emissive: 0xff0000,
        emissiveIntensity: 0.5
      });
      this.hpBarFg = new THREE.Mesh(hpFgGeometry, hpFgMaterial);
      this.hpBarFg.position.set(spawnPosition.x, spawnPosition.y + 0.51, spawnPosition.z);
      this.hpBarFg.rotation.x = -Math.PI / 4;
      scene.add(this.hpBarFg);
    }
  }

  setTypeStats(type) {
    switch(type) {
      case 'fast':
        this.speed = 1.5; // Greatly reduced from 4
        this.hp = 3; // Reduced for army feel
        this.xpValue = 5; // Lower individual XP
        this.color = 0xe6f7ff; // Light blue (angelic)
        this.size = 0.2; // Smaller
        break;
      case 'tank':
        this.speed = 0.4; // Greatly reduced from 1
        this.hp = 15; // Reduced for army feel
        this.xpValue = 20; // Lower individual XP
        this.color = 0xffffcc; // Light gold (angelic)
        this.size = 0.4; // Smaller
        break;
      case 'elite':
        this.speed = 0.5; // Greatly reduced from 1.0
        this.hp = 30; // Reduced for army feel
        this.xpValue = 50; // Lower individual XP
        this.color = 0xffffff; // Pure white (archangel)
        this.size = 0.5; // Smaller
        this.dropsChest = true;
        break;
      default: // normal
        this.speed = 0.8; // Greatly reduced from 2
        this.hp = 5; // Reduced for army feel
        this.xpValue = 8; // Lower individual XP
        this.color = 0xffffff; // White (angelic)
        this.size = 0.25; // Smaller
    }
  }

  update(deltaTime, gatePosition) {
    if (!this.alive) return;

    // Move toward gate
    const direction = new THREE.Vector3()
      .subVectors(gatePosition, this.mesh.position)
      .normalize();

    this.mesh.position.addScaledVector(direction, this.speed * deltaTime);

    // Update halo position and rotation (spinning for effect)
    if (this.halo) {
      this.halo.position.x = this.mesh.position.x;
      this.halo.position.y = this.mesh.position.y + this.size * 1.3;
      this.halo.position.z = this.mesh.position.z;
      this.halo.rotation.z += deltaTime * 2; // Spin the halo
    }

    // Update wings position for elite enemies
    if (this.leftWing && this.rightWing) {
      this.leftWing.position.x = this.mesh.position.x - this.size * 0.5;
      this.leftWing.position.y = this.mesh.position.y;
      this.leftWing.position.z = this.mesh.position.z;

      this.rightWing.position.x = this.mesh.position.x + this.size * 0.5;
      this.rightWing.position.y = this.mesh.position.y;
      this.rightWing.position.z = this.mesh.position.z;

      // Flap wings slightly
      const flapAngle = Math.sin(Date.now() * 0.005) * 0.3;
      this.leftWing.rotation.y = Math.PI / 2 + flapAngle;
      this.rightWing.rotation.y = -Math.PI / 2 - flapAngle;
    }

    // Update health bar position
    if (this.hpBarBg && this.hpBarFg) {
      this.hpBarBg.position.x = this.mesh.position.x;
      this.hpBarBg.position.z = this.mesh.position.z;
      this.hpBarFg.position.x = this.mesh.position.x - 0.225 * (1 - this.hp / this.maxHp);
      this.hpBarFg.position.z = this.mesh.position.z;
    }
  }

  takeDamage(damage) {
    this.hp -= damage;
    this.updateHealthBar();
    if (this.hp <= 0) {
      this.destroy();
    }
  }

  updateHealthBar() {
    if (!this.hpBarFg) return;
    const hpPercent = Math.max(0, this.hp / this.maxHp);
    this.hpBarFg.scale.x = hpPercent;
  }

  destroy() {
    this.alive = false;
    this.scene.remove(this.mesh);
    if (this.mesh.geometry) this.mesh.geometry.dispose();
    if (this.mesh.material) this.mesh.material.dispose();

    // Clean up halo
    if (this.halo) {
      this.scene.remove(this.halo);
      if (this.halo.geometry) this.halo.geometry.dispose();
      if (this.halo.material) this.halo.material.dispose();
    }

    // Clean up wings
    if (this.leftWing) {
      this.scene.remove(this.leftWing);
      if (this.leftWing.geometry) this.leftWing.geometry.dispose();
      if (this.leftWing.material) this.leftWing.material.dispose();
    }
    if (this.rightWing) {
      this.scene.remove(this.rightWing);
      if (this.rightWing.geometry) this.rightWing.geometry.dispose();
      if (this.rightWing.material) this.rightWing.material.dispose();
    }

    if (this.hpBarBg) {
      this.scene.remove(this.hpBarBg);
      if (this.hpBarBg.geometry) this.hpBarBg.geometry.dispose();
      if (this.hpBarBg.material) this.hpBarBg.material.dispose();
    }

    if (this.hpBarFg) {
      this.scene.remove(this.hpBarFg);
      if (this.hpBarFg.geometry) this.hpBarFg.geometry.dispose();
      if (this.hpBarFg.material) this.hpBarFg.material.dispose();
    }
  }
}

class Chest {
  constructor(scene, position, weaponType) {
    this.scene = scene;
    this.position = position.clone();
    this.position.y = 0.5; // Raise it up a bit for visibility
    this.weaponType = weaponType;
    this.alive = true;

    console.log('Creating chest at:', this.position); // Debug

    // Create chest mesh (golden rotating cube - LARGER for visibility)
    const geometry = new THREE.BoxGeometry(0.6, 0.6, 0.6); // Increased from 0.4
    const material = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      emissive: 0xffaa00,
      emissiveIntensity: 3.0 // Increased brightness
    });
    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.position.copy(this.position);
    scene.add(this.mesh);

    this.rotationSpeed = 2;
  }

  update(deltaTime) {
    if (!this.alive) return;
    this.mesh.rotation.y += this.rotationSpeed * deltaTime;
  }

  destroy() {
    this.alive = false;
    console.log('Destroying chest'); // Debug
    if (this.mesh) {
      this.scene.remove(this.mesh);
      if (this.mesh.geometry) this.mesh.geometry.dispose();
      if (this.mesh.material) this.mesh.material.dispose();
    }
  }
}

class Weapon {
  constructor(type) {
    this.type = type;
    this.level = 1;
    this.setTypeStats(type);
  }

  setTypeStats(type) {
    switch(type) {
      case 'shadoworb': // Original weapon
        this.name = 'Shadow Orb';
        this.baseDamage = 10;
        this.baseFireRate = 1.5;
        this.baseProjectileCount = 1;
        this.basePierceCount = 0;
        this.baseProjectileSpeed = 15;
        this.baseDetectionRadius = 8;
        this.color = 0x8e44ad;
        this.effect = 'projectile';
        break;
      case 'aoe':
        this.name = 'Nova Pulse';
        this.baseDamage = 3; // Lower for always-on effect
        this.baseFireRate = 10; // Damage ticks per second
        this.baseRange = 2.5; // Aura radius
        this.color = 0x00ffff;
        this.effect = 'aoe';
        this.isPassive = true; // Always-on aura
        break;
      case 'explosion':
        this.name = 'Rocket Launcher';
        this.baseDamage = 50;
        this.baseFireRate = 0.33;
        this.baseProjectileSpeed = 10;
        this.baseExplosionRadius = 2;
        this.color = 0xff6600;
        this.effect = 'explosion';
        break;
      case 'laser':
        this.name = 'Laser Beam';
        this.baseDamage = 1; // Reduced from 5
        this.baseFireRate = 6;
        this.baseRange = 10;
        this.color = 0xff0000;
        this.effect = 'laser';
        break;
      case 'flamethrower':
        this.name = 'Flamethrower';
        this.baseDamage = 8;
        this.baseFireRate = 3;
        this.baseRange = 4;
        this.color = 0xff4500;
        this.effect = 'flamethrower';
        break;
      case 'lightning':
        this.name = 'Chain Lightning';
        this.baseDamage = 20;
        this.baseFireRate = 1.5;
        this.baseRange = 12;
        this.baseChainCount = 1;
        this.baseChainRange = 3;
        this.color = 0x00ffff;
        this.effect = 'lightning';
        break;
    }

    // Modifiers
    this.modifiers = {
      damageMultiplier: 1,
      fireRateMultiplier: 1,
      rangeMultiplier: 1,
      projectileCountBonus: 0,
      pierceCountBonus: 0,
      chainCountBonus: 0,
      chainRangeBonus: 0,
      explosionRadiusBonus: 0,
      projectileSpeedBonus: 0
    };
  }

  // Computed properties
  get damage() { return this.baseDamage * this.modifiers.damageMultiplier * this.level; }
  get fireRate() { return this.baseFireRate * this.modifiers.fireRateMultiplier; }
  get range() { return (this.baseRange || this.baseDetectionRadius || 5) * this.modifiers.rangeMultiplier; }
  get projectileCount() { return (this.baseProjectileCount || 0) + this.modifiers.projectileCountBonus; }
  get pierceCount() { return (this.basePierceCount || 0) + this.modifiers.pierceCountBonus; }
  get projectileSpeed() { return (this.baseProjectileSpeed || 15) + this.modifiers.projectileSpeedBonus; }
  get chainCount() { return (this.baseChainCount || 0) + this.modifiers.chainCountBonus; }
  get chainRange() { return (this.baseChainRange || 0) + this.modifiers.chainRangeBonus; }
  get explosionRadius() { return (this.baseExplosionRadius || 0) + this.modifiers.explosionRadiusBonus; }

  applyModifier(modifierName, value, isAdditive = false) {
    if (isAdditive) {
      this.modifiers[modifierName] += value;
    } else {
      this.modifiers[modifierName] *= value;
    }
  }

  upgrade() {
    this.level++;
  }
}

class Gate {
  constructor(scene) {
    this.scene = scene;
    this.hp = 100;
    this.maxHp = 100;
    this.position = new THREE.Vector3(-9, 0.5, 0); // Left edge of smaller play area

    // Create gates of hell - dark stone pillars
    const pillarGeometry = new THREE.BoxGeometry(0.8, 4, 0.8);
    const pillarMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a0a0a, // Very dark red/black stone
      emissive: 0x330000,
      emissiveIntensity: 0.3,
      roughness: 0.9,
      metalness: 0.1
    });

    // Left pillar
    this.leftPillar = new THREE.Mesh(pillarGeometry, pillarMaterial);
    this.leftPillar.position.set(-9, 2, -2.5);
    scene.add(this.leftPillar);

    // Right pillar
    this.rightPillar = new THREE.Mesh(pillarGeometry, pillarMaterial);
    this.rightPillar.position.set(-9, 2, 2.5);
    scene.add(this.rightPillar);

    // Archway connecting pillars
    const archGeometry = new THREE.BoxGeometry(0.6, 0.8, 6);
    const archMaterial = new THREE.MeshStandardMaterial({
      color: 0x0d0606,
      emissive: 0x4d0000,
      emissiveIntensity: 0.4,
      roughness: 0.8
    });
    this.arch = new THREE.Mesh(archGeometry, archMaterial);
    this.arch.position.set(-9, 4, 0);
    scene.add(this.arch);

    // Central gate mesh (dark iron bars)
    const gateGeometry = new THREE.BoxGeometry(0.3, 3.5, 5);
    const gateMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a0000,
      emissive: 0x660000,
      emissiveIntensity: 0.8,
      roughness: 0.4,
      metalness: 0.6
    });
    this.mesh = new THREE.Mesh(gateGeometry, gateMaterial);
    this.mesh.position.copy(this.position);
    scene.add(this.mesh);

    // Add glowing red cracks/runes on gate
    for (let i = 0; i < 5; i++) {
      const runeGeometry = new THREE.SphereGeometry(0.1, 8, 8);
      const runeMaterial = new THREE.MeshBasicMaterial({
        color: 0xff0000,
        emissive: 0xff0000,
        emissiveIntensity: 3.0
      });
      const rune = new THREE.Mesh(runeGeometry, runeMaterial);
      rune.position.set(-8.8, 0.5 + i * 0.7, -2 + i * 1);
      scene.add(rune);
    }

    // Add flame particles at the base
    this.flames = [];
    for (let i = 0; i < 8; i++) {
      const flameGeometry = new THREE.ConeGeometry(0.15, 0.4, 6);
      const flameMaterial = new THREE.MeshBasicMaterial({
        color: i % 2 === 0 ? 0xff4500 : 0xff6600,
        emissive: i % 2 === 0 ? 0xff4500 : 0xff6600,
        emissiveIntensity: 2.0,
        transparent: true,
        opacity: 0.8
      });
      const flame = new THREE.Mesh(flameGeometry, flameMaterial);
      flame.position.set(-9, 0.2, -2.5 + i * 0.7);
      scene.add(flame);
      this.flames.push(flame);
    }

    // Dark mist/fog at base
    const mistGeometry = new THREE.PlaneGeometry(2, 6);
    const mistMaterial = new THREE.MeshBasicMaterial({
      color: 0x1a0000,
      transparent: true,
      opacity: 0.4,
      side: THREE.DoubleSide
    });
    this.mist = new THREE.Mesh(mistGeometry, mistMaterial);
    this.mist.position.set(-8.5, 0.1, 0);
    this.mist.rotation.x = -Math.PI / 2;
    scene.add(this.mist);

    // Store reference for animation
    this.time = 0;
  }

  takeDamage(damage) {
    this.hp = Math.max(0, this.hp - damage);
    // Intensify red glow when damaged
    if (this.mesh && this.mesh.material) {
      this.mesh.material.emissiveIntensity = Math.min(2.0, 0.8 + (1 - this.hp / this.maxHp));
    }
  }

  update(deltaTime) {
    this.time += deltaTime;

    // Animate flames flickering
    this.flames.forEach((flame, i) => {
      flame.scale.y = 1 + Math.sin(this.time * 5 + i) * 0.3;
      flame.position.y = 0.2 + Math.abs(Math.sin(this.time * 3 + i)) * 0.1;
    });

    // Animate mist
    if (this.mist) {
      this.mist.material.opacity = 0.3 + Math.sin(this.time * 2) * 0.1;
    }
  }

  isDestroyed() {
    return this.hp <= 0;
  }
}

class Game {
  constructor() {
    this.canvas = document.querySelector("canvas.webgl");
    this.sizes = {
      width: window.innerWidth,
      height: window.innerHeight,
    };

    this.gameState = 'notStarted'; // notStarted, playing, paused
    this.isPaused = false;
    this.gameOver = false;

    // XP and Level system
    this.xp = 0;
    this.level = 1;
    this.xpToNextLevel = 100;

    // Progressive spawn system - balanced difficulty
    this.gameTime = 0;
    this.spawnInterval = 0.7; // Balanced start (between 0.3 and 1.2)
    this.minSpawnInterval = 0.12; // Balanced minimum spawn rate (between 0.1 and 0.15)

    this.init();
    this.setupKeyboard();
  }

  init() {
    this.setupScene();
    this.setupPostProcessing();
    this.setupEntities();
    this.setupUI();
    this.setupResize();
    this.animate();
  }

  setupScene() {
    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0a0a);

    // Camera (higher up and looking down to see entire play area)
    this.camera = new THREE.PerspectiveCamera(
      60,
      this.sizes.width / this.sizes.height,
      0.1,
      100
    );
    this.camera.position.set(0, 20, 0);
    this.camera.lookAt(0, 0, 0);

    // Floor (MUCH SMALLER - 20x12 for tight play area)
    const floorGeometry = new THREE.PlaneGeometry(20, 12);
    const floorMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      roughness: 0.8,
      metalness: 0.2
    });
    this.floor = new THREE.Mesh(floorGeometry, floorMaterial);
    this.floor.rotation.x = -Math.PI / 2;
    this.scene.add(this.floor);

    // Add visual boundary markers (bright red edges)
    const boundaryMaterial = new THREE.LineBasicMaterial({ color: 0xff0000, linewidth: 2 });

    // Top boundary
    const topPoints = [new THREE.Vector3(-10, 0.1, -6), new THREE.Vector3(10, 0.1, -6)];
    const topGeometry = new THREE.BufferGeometry().setFromPoints(topPoints);
    const topLine = new THREE.Line(topGeometry, boundaryMaterial);
    this.scene.add(topLine);

    // Bottom boundary
    const bottomPoints = [new THREE.Vector3(-10, 0.1, 6), new THREE.Vector3(10, 0.1, 6)];
    const bottomGeometry = new THREE.BufferGeometry().setFromPoints(bottomPoints);
    const bottomLine = new THREE.Line(bottomGeometry, boundaryMaterial);
    this.scene.add(bottomLine);

    // Left boundary
    const leftPoints = [new THREE.Vector3(-10, 0.1, -6), new THREE.Vector3(-10, 0.1, 6)];
    const leftGeometry = new THREE.BufferGeometry().setFromPoints(leftPoints);
    const leftLine = new THREE.Line(leftGeometry, boundaryMaterial);
    this.scene.add(leftLine);

    // Right boundary
    const rightPoints = [new THREE.Vector3(10, 0.1, -6), new THREE.Vector3(10, 0.1, 6)];
    const rightGeometry = new THREE.BufferGeometry().setFromPoints(rightPoints);
    const rightLine = new THREE.Line(rightGeometry, boundaryMaterial);
    this.scene.add(rightLine);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    this.scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 5);
    this.scene.add(directionalLight);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
    });
    this.renderer.setSize(this.sizes.width, this.sizes.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  }

  setupPostProcessing() {
    // Bloom effect for neon aesthetic
    this.composer = new EffectComposer(this.renderer);

    const renderPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(renderPass);

    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(this.sizes.width, this.sizes.height),
      1.5,  // strength
      0.4,  // radius
      0.85  // threshold
    );
    this.composer.addPass(bloomPass);
  }

  setupEntities() {
    // Initialize game entities
    this.player = new Player(this.scene);
    this.gate = new Gate(this.scene);
    this.enemies = [];
    this.projectiles = [];
    this.chests = [];
    this.effects = [];
    this.effectMeshes = []; // Track effect meshes for cleanup

    // Spawn timer
    this.spawnTimer = 0;
    this.eliteSpawnTimer = 0;
    this.eliteSpawnInterval = 22; // Elite every 22 seconds (balanced between 15 and 30)

    // Difficulty scaling
    this.difficultyMultiplier = 1.0;

    // Background music
    this.backgroundMusic = new Audio('/gates-on-overdrive.mp3');
    this.backgroundMusic.loop = true;
    this.backgroundMusic.volume = 0.5; // 50% volume
  }

  setupUI() {
    // HUD
    this.hudElement = document.getElementById('hud');
    this.gateHpElement = document.getElementById('gate-hp');
    this.xpLevelElement = document.getElementById('xp-level');
    this.weaponsListElement = document.getElementById('weapons-list');

    // Upgrade UI
    this.upgradeOverlay = document.getElementById('upgrade-overlay');
    this.upgradeCardsContainer = document.getElementById('upgrade-cards');

    // Game Over UI
    this.gameOverOverlay = document.getElementById('game-over-overlay');

    // Pause UI
    this.pauseOverlay = document.getElementById('pause-overlay');

    // Start screen UI
    this.startOverlay = document.getElementById('start-overlay');
    if (this.startOverlay) {
      this.startOverlay.style.display = 'flex';
    }
  }

  setupResize() {
    window.addEventListener("resize", () => {
      this.sizes.width = window.innerWidth;
      this.sizes.height = window.innerHeight;

      this.camera.aspect = this.sizes.width / this.sizes.height;
      this.camera.updateProjectionMatrix();

      this.renderer.setSize(this.sizes.width, this.sizes.height);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.composer.setSize(this.sizes.width, this.sizes.height);
    });
  }

  setupKeyboard() {
    window.addEventListener('keydown', (e) => {
      // Space key - Start/Pause/Unpause
      if (e.code === 'Space') {
        e.preventDefault();

        if (this.gameState === 'notStarted') {
          this.startGame();
        } else if (this.gameState === 'playing') {
          this.pauseGame();
        } else if (this.gameState === 'paused') {
          this.unpauseGame();
        }
      }

      // R key - Restart
      if (e.key.toLowerCase() === 'r') {
        e.preventDefault();
        this.restartGame();
      }
    });
  }

  startGame() {
    this.gameState = 'playing';
    this.isPaused = false;
    if (this.startOverlay) {
      this.startOverlay.style.display = 'none';
    }
    if (this.pauseOverlay) {
      this.pauseOverlay.style.display = 'none';
    }

    // Start background music
    if (this.backgroundMusic && this.backgroundMusic.paused) {
      this.backgroundMusic.play();
    }
  }

  pauseGame() {
    this.gameState = 'paused';
    this.isPaused = true;
    if (this.pauseOverlay) {
      this.pauseOverlay.style.display = 'flex';
    }

    // Pause background music
    if (this.backgroundMusic && !this.backgroundMusic.paused) {
      this.backgroundMusic.pause();
    }
  }

  unpauseGame() {
    this.gameState = 'playing';
    this.isPaused = false;
    if (this.pauseOverlay) {
      this.pauseOverlay.style.display = 'none';
    }

    // Resume background music
    if (this.backgroundMusic && this.backgroundMusic.paused) {
      this.backgroundMusic.play();
    }
  }

  restartGame() {
    // Reload the page to restart
    window.location.reload();
  }

  spawnEnemy(forceType = null) {
    const x = 9; // Right edge of smaller play area
    const z = (Math.random() - 0.5) * 10; // Random Z position within smaller bounds
    const spawnPos = new THREE.Vector3(x, 0.3, z);

    // Determine enemy type
    let type = forceType;
    if (!type) {
      const rand = Math.random();
      if (rand < 0.6) {
        type = 'normal';
      } else if (rand < 0.85) {
        type = 'fast';
      } else {
        type = 'tank';
      }
    }

    const enemy = new Enemy(this.scene, spawnPos, type, this.difficultyMultiplier);
    this.enemies.push(enemy);
  }

  spawnChest(position, weaponType) {
    const chest = new Chest(this.scene, position, weaponType);
    this.chests.push(chest);
  }

  showUpgradeCards() {
    this.isPaused = true;
    this.upgradeOverlay.style.display = 'flex';

    // Generate 3 random upgrades
    const upgrades = this.generateRandomUpgrades(3);
    this.upgradeCardsContainer.innerHTML = '';

    upgrades.forEach(upgrade => {
      const card = document.createElement('div');
      card.className = 'upgrade-card';
      card.innerHTML = `
        <h3>${upgrade.name}</h3>
        <p>${upgrade.description}</p>
      `;
      card.addEventListener('click', () => {
        this.applyUpgrade(upgrade);
        this.hideUpgradeCards();
      });
      this.upgradeCardsContainer.appendChild(card);
    });
  }

  hideUpgradeCards() {
    this.upgradeOverlay.style.display = 'none';
    this.isPaused = false;
  }

  addXP(amount) {
    this.xp += amount;
    if (this.xp >= this.xpToNextLevel) {
      this.levelUp();
    }
  }

  levelUp() {
    this.level++;
    this.xp -= this.xpToNextLevel;
    this.xpToNextLevel = Math.floor(this.xpToNextLevel * 1.15); // 15% more XP per level (was 30%)
    this.showUpgradeCards();
  }

  generateRandomUpgrades(count) {
    const allUpgrades = [];

    // Add upgrades for each weapon the player has
    this.player.weapons.forEach(weapon => {
      // Damage upgrade
      allUpgrades.push({
        name: `${weapon.name}: +30% Damage`,
        description: `Increase ${weapon.name} damage by 30%`,
        weaponType: weapon.type,
        apply: () => weapon.applyModifier('damageMultiplier', 1.3)
      });

      // Fire Rate upgrade
      allUpgrades.push({
        name: `${weapon.name}: +5% Fire Rate`,
        description: `${weapon.name} fires 5% faster`,
        weaponType: weapon.type,
        apply: () => weapon.applyModifier('fireRateMultiplier', 1.05)
      });

      // Range upgrade
      allUpgrades.push({
        name: `${weapon.name}: +30% Range`,
        description: `Increase ${weapon.name} range by 30%`,
        weaponType: weapon.type,
        apply: () => weapon.applyModifier('rangeMultiplier', 1.3)
      });

      // Weapon-specific unique upgrades
      if (weapon.effect === 'projectile') {
        allUpgrades.push({
          name: `${weapon.name}: +1 Projectile`,
          description: `Fire one more projectile`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('projectileCountBonus', 1, true)
        });

        allUpgrades.push({
          name: `${weapon.name}: +1 Pierce`,
          description: `Projectiles pierce one more enemy`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('pierceCountBonus', 1, true)
        });

        allUpgrades.push({
          name: `${weapon.name}: Faster Projectiles`,
          description: `Projectiles travel 50% faster`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('projectileSpeedBonus', weapon.baseProjectileSpeed * 0.5, true)
        });
      }

      if (weapon.effect === 'explosion') {
        allUpgrades.push({
          name: `${weapon.name}: +50% Blast Radius`,
          description: `Increase explosion radius`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('explosionRadiusBonus', weapon.baseExplosionRadius * 0.5, true)
        });

        allUpgrades.push({
          name: `${weapon.name}: Cluster Bombs`,
          description: `Fire 2 rockets at once`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('projectileCountBonus', 1, true)
        });
      }

      if (weapon.effect === 'lightning') {
        allUpgrades.push({
          name: `${weapon.name}: +2 Chain Jumps`,
          description: `Lightning jumps to 2 more enemies`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('chainCountBonus', 2, true)
        });

        allUpgrades.push({
          name: `${weapon.name}: +50% Chain Range`,
          description: `Lightning can jump further between enemies`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('chainRangeBonus', weapon.baseChainRange * 0.5, true)
        });

        allUpgrades.push({
          name: `${weapon.name}: Overcharged`,
          description: `Lightning deals 50% more damage but fires slower`,
          weaponType: weapon.type,
          apply: () => {
            weapon.applyModifier('damageMultiplier', 1.5);
            weapon.applyModifier('fireRateMultiplier', 0.8);
          }
        });
      }

      if (weapon.effect === 'aoe') {
        allUpgrades.push({
          name: `${weapon.name}: Double Radius`,
          description: `Pulse affects twice the area`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('rangeMultiplier', 2.0)
        });

        allUpgrades.push({
          name: `${weapon.name}: Rapid Pulse`,
          description: `Fire 50% faster but deal 20% less damage`,
          weaponType: weapon.type,
          apply: () => {
            weapon.applyModifier('fireRateMultiplier', 1.5);
            weapon.applyModifier('damageMultiplier', 0.8);
          }
        });
      }

      if (weapon.effect === 'laser') {
        allUpgrades.push({
          name: `${weapon.name}: Piercing Beam`,
          description: `Laser hits all enemies in line`,
          weaponType: weapon.type,
          apply: () => weapon.applyModifier('pierceCountBonus', 100, true) // Effectively infinite
        });

        allUpgrades.push({
          name: `${weapon.name}: Concentrated Beam`,
          description: `Double damage but half range`,
          weaponType: weapon.type,
          apply: () => {
            weapon.applyModifier('damageMultiplier', 2.0);
            weapon.applyModifier('rangeMultiplier', 0.5);
          }
        });
      }

      if (weapon.effect === 'flamethrower') {
        allUpgrades.push({
          name: `${weapon.name}: Inferno`,
          description: `Double range and damage`,
          weaponType: weapon.type,
          apply: () => {
            weapon.applyModifier('rangeMultiplier', 2.0);
            weapon.applyModifier('damageMultiplier', 2.0);
          }
        });

        allUpgrades.push({
          name: `${weapon.name}: Continuous Blaze`,
          description: `Fire constantly but deal less damage`,
          weaponType: weapon.type,
          apply: () => {
            weapon.applyModifier('fireRateMultiplier', 3.0);
            weapon.applyModifier('damageMultiplier', 0.6);
          }
        });
      }
    });

    // Add general player upgrades
    allUpgrades.push({
      name: 'Movement Speed +30%',
      description: 'Move 30% faster',
      apply: () => { this.player.speed *= 1.3; }
    });

    allUpgrades.push({
      name: 'Gate Fortification',
      description: 'Gate gains +25 max HP',
      apply: () => {
        this.gate.maxHp += 25;
        this.gate.hp += 25;
      }
    });

    // Shuffle and pick random upgrades
    const shuffled = allUpgrades.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(count, shuffled.length));
  }

  applyUpgrade(upgrade) {
    upgrade.apply();
  }

  showGameOver() {
    this.gameOver = true;
    this.gameOverOverlay.style.display = 'flex';
  }

  updateHUD() {
    const gateHpPercent = (this.gate.hp / this.gate.maxHp) * 100;
    this.gateHpElement.textContent = `Gate HP: ${Math.ceil(this.gate.hp)}/${this.gate.maxHp}`;

    const xpPercent = ((this.xp / this.xpToNextLevel) * 100).toFixed(0);
    this.xpLevelElement.textContent = `Level ${this.level} - XP: ${this.xp}/${this.xpToNextLevel} (${xpPercent}%)`;

    // Update weapons list
    if (this.weaponsListElement) {
      this.weaponsListElement.innerHTML = '';
      this.player.weapons.forEach(weapon => {
        const weaponItem = document.createElement('div');
        weaponItem.className = 'weapon-item';

        const name = document.createElement('div');
        name.className = 'weapon-item-name';
        name.textContent = `${weapon.name} (Lvl ${weapon.level})`;

        const stats = document.createElement('div');
        stats.className = 'weapon-item-stats';
        stats.innerHTML = `
          Dmg: ${weapon.damage.toFixed(1)} | FR: ${weapon.fireRate.toFixed(1)}/s<br>
          Range: ${weapon.range.toFixed(1)}
        `;

        weaponItem.appendChild(name);
        weaponItem.appendChild(stats);
        this.weaponsListElement.appendChild(weaponItem);
      });
    }
  }

  renderEffects() {
    // Clean up old effect meshes
    this.effectMeshes.forEach(mesh => {
      this.scene.remove(mesh);
      if (mesh.geometry) mesh.geometry.dispose();
      if (mesh.material) mesh.material.dispose();
    });
    this.effectMeshes = [];

    // Render current effects
    this.effects.forEach(effect => {
      const progress = effect.age / effect.lifetime;
      const opacity = 1 - progress;

      switch(effect.type) {
        case 'laser': {
          // Red laser beam
          const points = [effect.start, effect.end];
          const geometry = new THREE.BufferGeometry().setFromPoints(points);
          const material = new THREE.LineBasicMaterial({
            color: effect.color,
            linewidth: 3,
            transparent: true,
            opacity: opacity
          });
          const laser = new THREE.Line(geometry, material);
          this.scene.add(laser);
          this.effectMeshes.push(laser);
          break;
        }
        case 'lightning': {
          // Chain lightning bolts between positions
          if (effect.chainPositions && effect.chainPositions.length > 1) {
            for (let i = 0; i < effect.chainPositions.length - 1; i++) {
              const start = effect.chainPositions[i];
              const end = effect.chainPositions[i + 1];

              // Create jagged lightning path
              const segments = 5;
              const points = [start.clone()];
              for (let j = 1; j < segments; j++) {
                const t = j / segments;
                const point = new THREE.Vector3().lerpVectors(start, end, t);
                // Add random offset for jagged effect
                point.x += (Math.random() - 0.5) * 0.3;
                point.y += (Math.random() - 0.5) * 0.3;
                point.z += (Math.random() - 0.5) * 0.3;
                points.push(point);
              }
              points.push(end.clone());

              const geometry = new THREE.BufferGeometry().setFromPoints(points);
              const material = new THREE.LineBasicMaterial({
                color: effect.color,
                linewidth: 2,
                transparent: true,
                opacity: opacity * 0.9
              });
              const bolt = new THREE.Line(geometry, material);
              this.scene.add(bolt);
              this.effectMeshes.push(bolt);

              // Add glow spheres at junction points
              const glowGeometry = new THREE.SphereGeometry(0.15, 6, 6);
              const glowMaterial = new THREE.MeshBasicMaterial({
                color: effect.color,
                emissive: effect.color,
                emissiveIntensity: 3.0,
                transparent: true,
                opacity: opacity
              });
              const glow = new THREE.Mesh(glowGeometry, glowMaterial);
              glow.position.copy(end);
              this.scene.add(glow);
              this.effectMeshes.push(glow);
            }
          }
          break;
        }
        case 'aoe': {
          // Blue expanding circle (Nova Pulse)
          const radius = effect.maxRadius * progress;
          const circleGeometry = new THREE.RingGeometry(radius * 0.8, radius, 32);
          const circleMaterial = new THREE.MeshBasicMaterial({
            color: effect.color,
            emissive: effect.color,
            emissiveIntensity: 2.0,
            transparent: true,
            opacity: opacity * 0.7,
            side: THREE.DoubleSide
          });
          const circle = new THREE.Mesh(circleGeometry, circleMaterial);
          circle.position.copy(effect.position);
          circle.position.y = 0.1;
          circle.rotation.x = -Math.PI / 2;
          this.scene.add(circle);
          this.effectMeshes.push(circle);
          break;
        }
        case 'flamethrower': {
          // Orange/red flame cone particles
          const particleCount = 20;
          const particles = [];

          for (let i = 0; i < particleCount; i++) {
            const distance = (Math.random() * effect.range) * progress;
            const spread = Math.random() * 0.8 - 0.4;

            const position = effect.position.clone()
              .addScaledVector(effect.direction, distance)
              .add(new THREE.Vector3(
                spread * Math.random(),
                Math.random() * 0.5,
                spread * Math.random()
              ));

            particles.push(position);
          }

          particles.forEach((pos, i) => {
            const size = 0.15 + Math.random() * 0.15;
            const flameGeometry = new THREE.SphereGeometry(size, 6, 6);
            // Mix orange and red for flame effect
            const flameColor = i % 2 === 0 ? 0xff4500 : 0xff6600;
            const flameMaterial = new THREE.MeshBasicMaterial({
              color: flameColor,
              emissive: flameColor,
              emissiveIntensity: 2.0,
              transparent: true,
              opacity: opacity * (0.6 + Math.random() * 0.4)
            });
            const flame = new THREE.Mesh(flameGeometry, flameMaterial);
            flame.position.copy(pos);
            this.scene.add(flame);
            this.effectMeshes.push(flame);
          });
          break;
        }
      }
    });
  }

  update(deltaTime) {
    // Only update if game is playing (not paused, not game over, and started)
    if (this.gameState !== 'playing' || this.isPaused || this.gameOver) return;

    // Track game time for progressive difficulty
    this.gameTime += deltaTime;

    // Update difficulty multiplier (enemies get 5% stronger every 37 seconds - balanced)
    this.difficultyMultiplier = 1 + (Math.floor(this.gameTime / 37) * 0.05);

    // Update spawn rate (gets faster over time, balanced acceleration)
    const targetSpawnInterval = Math.max(
      this.minSpawnInterval,
      this.spawnInterval - (this.gameTime * 0.007) // Balanced between 0.005 and 0.01
    );

    // Update player
    this.player.update(deltaTime, this.enemies, this.projectiles, this.effects);

    // Update gate animations
    if (this.gate && this.gate.update) {
      this.gate.update(deltaTime);
    }

    // Update chests
    for (let i = this.chests.length - 1; i >= 0; i--) {
      const chest = this.chests[i];
      if (!chest || !chest.alive) {
        this.chests.splice(i, 1);
        continue;
      }

      chest.update(deltaTime);

      // Check collision with player (larger radius for easier pickup)
      if (this.player && this.player.mesh && chest && chest.mesh) {
        try {
          const distance = this.player.mesh.position.distanceTo(chest.mesh.position);
          if (distance < 1.5) { // Increased from 0.7 to 1.5 for easier pickup
            // Check if all weapons are unlocked
            const allWeaponTypes = ['shadoworb', 'aoe', 'explosion', 'laser', 'flamethrower', 'lightning'];
            const hasAllWeapons = allWeaponTypes.every(type =>
              this.player.weapons.some(w => w.type === type)
            );

            if (hasAllWeapons) {
              // All weapons unlocked - give level up upgrade instead
              console.log('All weapons unlocked! Chest gives upgrade.'); // Debug
              chest.destroy();
              this.chests.splice(i, 1);
              this.showUpgradeCards();
            } else {
              // Add new weapon
              const weaponTypes = ['aoe', 'explosion', 'laser', 'flamethrower', 'lightning'];
              // Filter out weapons player already has
              const availableWeapons = weaponTypes.filter(type =>
                !this.player.weapons.some(w => w.type === type)
              );

              if (availableWeapons.length > 0) {
                const randomWeapon = chest.weaponType || availableWeapons[Math.floor(Math.random() * availableWeapons.length)];
                console.log('Picked up weapon:', randomWeapon); // Debug
                this.player.addWeapon(randomWeapon);
              }

              chest.destroy();
              this.chests.splice(i, 1);
            }
          }
        } catch (e) {
          console.error('Chest pickup error:', e);
          // Safety: just remove the chest
          if (chest && chest.destroy) chest.destroy();
          this.chests.splice(i, 1);
        }
      }
    }

    // Update effects (visual only, damage already applied)
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const effect = this.effects[i];
      effect.age += deltaTime;

      if (effect.age >= effect.lifetime) {
        this.effects.splice(i, 1);
      }
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const projectile = this.projectiles[i];
      if (!projectile) {
        this.projectiles.splice(i, 1);
        continue;
      }

      projectile.update(deltaTime);

      if (!projectile.alive) {
        this.projectiles.splice(i, 1);
        continue;
      }

      // Check collision with enemies
      for (const enemy of this.enemies) {
        if (!enemy || !enemy.alive || !enemy.mesh || !projectile.mesh) continue;

        const distance = projectile.mesh.position.distanceTo(enemy.mesh.position);
        if (distance < 0.4) {
          const wasAlive = enemy.hp > 0;
          const enemyPos = enemy.mesh.position.clone();
          const dropsChest = enemy.dropsChest;

          enemy.takeDamage(projectile.damage);

          // Handle explosion (Rocket Launcher)
          if (projectile.isExplosive && projectile.explosionRadius > 0) {
            this.enemies.forEach(e => {
              if (e && e.alive && e.mesh && e !== enemy) {
                const dist = enemyPos.distanceTo(e.mesh.position);
                if (dist <= projectile.explosionRadius) {
                  e.takeDamage(projectile.damage * 0.5); // Half damage for splash
                }
              }
            });
          }

          // Grant XP and drop chest if enemy died
          if (wasAlive && enemy.hp <= 0) {
            this.addXP(enemy.xpValue);
            if (dropsChest) {
              console.log('Elite died! Spawning chest at:', enemyPos); // Debug
              this.spawnChest(enemyPos);
            }
          }

          projectile.onHit();
          break;
        }
      }
    }

    // Update enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (!enemy || !enemy.mesh) {
        this.enemies.splice(i, 1);
        continue;
      }

      enemy.update(deltaTime, this.gate.position);

      if (!enemy.alive) {
        this.enemies.splice(i, 1);
        continue;
      }

      // Check collision with gate - enemy dies, gate takes damage
      if (this.gate && this.gate.position && enemy.mesh && enemy.mesh.position) {
        try {
          const distanceToGate = enemy.mesh.position.distanceTo(this.gate.position);
          if (distanceToGate < 3.5) {
            // Gate takes damage
            if (this.gate.takeDamage) {
              this.gate.takeDamage(5); // Reduced from 10
            }
            // Enemy dies
            if (enemy.destroy) {
              enemy.destroy();
            }
            this.enemies.splice(i, 1);
          }
        } catch (e) {
          console.error('Gate collision error:', e);
          // Safety: just remove the enemy
          if (enemy && enemy.destroy) enemy.destroy();
          this.enemies.splice(i, 1);
        }
      }
    }

    // Check game over
    if (this.gate.isDestroyed()) {
      this.showGameOver();
    }

    // Spawn enemies with progressive rate
    this.spawnTimer += deltaTime;
    if (this.spawnTimer >= targetSpawnInterval) {
      this.spawnEnemy();
      this.spawnTimer = 0;
    }

    // Spawn elite enemies periodically
    this.eliteSpawnTimer += deltaTime;
    if (this.eliteSpawnTimer >= this.eliteSpawnInterval) {
      this.spawnEnemy('elite');
      this.eliteSpawnTimer = 0;
    }

    // Update HUD
    this.updateHUD();
  }

  animate() {
    this.clock = this.clock || new THREE.Clock();
    const deltaTime = Math.min(this.clock.getDelta(), 0.1); // Cap delta time

    this.update(deltaTime);

    // Render visual effects
    this.renderEffects();

    // Render with bloom
    this.composer.render();

    window.requestAnimationFrame(() => this.animate());
  }
}

// Start the game
const game = new Game();
